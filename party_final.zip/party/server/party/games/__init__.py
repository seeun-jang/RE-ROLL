"""서버에 등록된 미니게임 목록. 새 게임은 여기에 한 줄 추가한다."""

from __future__ import annotations

from ..minigame import MiniGame
from .fruit.game import FruitGame
from .garden.game import GardenGame
from .kendo.game import KendoGame
from .mimic.game import MimicGame
from .mugunghwa.game import MugunghwaGame
from .palm.game import PalmGame
from .quiz.game import QuizGame
from .racing.game import RacingGame
from .spell.game import SpellGame
from .tug.game import TugGame

GAMES: dict[str, type[MiniGame]] = {
    TugGame.id: TugGame,
    PalmGame.id: PalmGame,
    QuizGame.id: QuizGame,
    SpellGame.id: SpellGame,
    MugunghwaGame.id: MugunghwaGame,
    MimicGame.id: MimicGame,
    FruitGame.id: FruitGame,
    GardenGame.id: GardenGame,
    KendoGame.id: KendoGame,
    RacingGame.id: RacingGame,
}
