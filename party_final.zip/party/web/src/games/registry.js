// =============================================================
// 미니게임 목록 (브라우저 쪽). 새 게임은 여기에 한 항목을 추가한다.
//
//   load()     화면 모듈: { mount(container, ctx) → { destroy() } }
//   loadSim()  LocalSession 전용 시험용 진행기: { Sim, createBots }
//
// id 는 서버(server/party/games/__init__.py)의 게임 id 와 같아야 한다.
// =============================================================

export const GAMES = Object.freeze({
  tug: {
    id: 'tug',
    title: '픽셀 줄다리기',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: 'Space: 박자에 맞춰 당기기 · M: 소리 끄기/켜기',
    load: () => import('./tug/minigame.js'),
    loadSim: () => import('./tug/sim/TugSim.js').then((m) => ({ Sim: m.TugSim, createBots: m.createBots })),
  },
  palm: {
    id: 'palm',
    title: '손바닥 밀치기',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: 'A/D: 균형 · J: 밀기(길게 누르면 차지) · K: 손 빼기 · L: 버티기 · M: 소리 끄기/켜기',
    load: () => import('./palm/minigame.js'),
    loadSim: () => import('./palm/sim/PalmSim.js').then((m) => ({ Sim: m.PalmSim, createBots: m.createBots })),
  },
  quiz: {
    id: 'quiz',
    title: '음성 퀴즈',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '스페이스: 버저 → 마이크로 정답 말하기(또는 타자 입력 후 Enter) · M: 소리 끄기/켜기',
    load: () => import('./quiz/minigame.js'),
    loadSim: () => import('./quiz/sim/QuizSim.js').then((m) => ({ Sim: m.QuizSim, createBots: m.createBots })),
  },
  spell: {
    id: 'spell',
    title: '주문을 외쳐라',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '주문 이름을 외치기 (파이어볼 · 아쿠아 샷 · 썬더 · 윈드 커터 · 아이스 실드 · 힐) 또는 숫자키 1~6 · M: 소리 끄기/켜기',
    load: () => import('./spell/minigame.js'),
    loadSim: () => import('./spell/sim/SpellSim.js').then((m) => ({ Sim: m.SpellSim, createBots: m.createBots })),
  },
  mugunghwa: {
    id: 'mugunghwa',
    title: '무궁화 꽃이 피었습니다',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '도망자: 스페이스를 누르고 있으면 전진 · 술래: 마이크에 "무궁화 꽃이 피었습니다" 외치기 · M: 소리 끄기/켜기',
    load: () => import('./mugunghwa/minigame.js'),
    loadSim: () => import('./mugunghwa/sim/MugunghwaSim.js').then((m) => ({ Sim: m.MugunghwaSim, createBots: m.createBots })),
  },
  mimic: {
    id: 'mimic',
    title: '소리 따라하기',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '제시 소리를 듣고, 내 차례에 마이크로 똑같이 따라 하기 (다른 사람 차례에는 조용히) · M: 소리 끄기/켜기',
    load: () => import('./mimic/minigame.js'),
    loadSim: () => import('./mimic/sim/MimicSim.js').then((m) => ({ Sim: m.MimicSim, createBots: m.createBots })),
  },
  fruit: {
    id: 'fruit',
    title: '과일자르기',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '마우스를 누른 채 긋기 또는 카메라 앞에서 검지 휘두르기로 과일 베기 (폭탄은 -20점) · M: 소리 끄기/켜기',
    load: () => import('./fruit/minigame.js'),
    loadSim: () => import('./fruit/sim/FruitSim.js').then((m) => ({ Sim: m.FruitSim, createBots: m.createBots })),
  },
  garden: {
    id: 'garden',
    title: '가든 디펜스',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: 'W/S·↑/↓ 레인 이동, Space(꾹) 사격 — 또는 손을 총 모양(ㄱ자)으로 만들어 높이로 조준, 검지를 구부려 발사 · M: 소리 끄기/켜기',
    load: () => import('./garden/minigame.js'),
    loadSim: () => import('./garden/sim/GardenSim.js').then((m) => ({ Sim: m.GardenSim, createBots: m.createBots })),
  },
  kendo: {
    id: 'kendo',
    title: '검도',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '←→ 이동 · Shift 기합(꾹) · Z 머리 · X 손목 · C 허리 · Space 막기(타이밍이 맞으면 받아치기) · M: 소리 끄기/켜기',
    load: () => import('./kendo/minigame.js'),
    loadSim: () => import('./kendo/sim/KendoSim.js').then((m) => ({ Sim: m.KendoSim, createBots: m.createBots })),
  },
  racing: {
    id: 'racing',
    title: '레이싱',
    minPlayers: 2,
    maxPlayers: 5,
    howTo: '두 손을 핸들처럼 들고 기울여 방향, 카메라 쪽으로 밀면 가속 (카메라를 쓸 수 없을 때만 ↑↓←→·Space) · M: 소리 끄기/켜기',
    load: () => import('./racing/minigame.js'),
    loadSim: () => import('./racing/sim/RacingSim.js').then((m) => ({ Sim: m.RacingSim, createBots: m.createBots })),
  },
});
