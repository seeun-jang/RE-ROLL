// [원본 fight-night/js/font.js 를 ES 모듈로 옮긴 것 — 내용은 원본 그대로, import/export 만 붙였다]
// =====================================================
// 3x5 비트맵 폰트 (숫자/영문 HUD 용) — 항상 픽셀이 딱 떨어짐
// =====================================================
const BITMAP_GLYPHS = {
  0: '111101101101111', 1: '010110010010111', 2: '111001111100111',
  3: '111001111001111', 4: '101101111001001', 5: '111100111001111',
  6: '111100111101111', 7: '111001001010010', 8: '111101111101111',
  9: '111101111001111',
  A: '010101111101101', B: '110101110101110', C: '011100100100011',
  D: '110101101101110', E: '111100110100111', F: '111100110100100',
  G: '011100101101011', H: '101101111101101', I: '111010010010111',
  J: '001001001101010', K: '101101110101101', L: '100100100100111',
  M: '101111111101101', N: '110101101101101', O: '010101101101010',
  P: '110101110100100', Q: '010101101110011', R: '110101110101101',
  S: '011100010001110', T: '111010010010010', U: '101101101101111',
  V: '101101101101010', W: '101101101111101', X: '101101010101101',
  Y: '101101010010010', Z: '111001010100111',
  '!': '010010010000010', '?': '110001010000010', ':': '000010000010000',
  '.': '000000000000010', '-': '000000111000000', '+': '000010111010000',
  '/': '001001010100100', '%': '101001010100101', ',': '000000000010100',
  '<': '001010100010001', '>': '100010001010100', "'": '010010000000000',
  '^': '010111010010010', // 위 화살표 (키 표시용)
};

const BitmapFont = {
  measure(str, scale = 1) {
    const s = String(str);
    return Math.max(0, s.length * 4 * scale - scale);
  },

  // align: left | center | right
  draw(ctx, str, x, y, color, opts = {}) {
    const scale = opts.scale || 1;
    const s = String(str).toUpperCase();
    const w = this.measure(s, scale);
    let px = x;
    if (opts.align === 'center') px = x - w / 2;
    else if (opts.align === 'right') px = x - w;
    px = Math.round(px);
    const py = Math.round(y);
    if (opts.shadow) this._raw(ctx, s, px, py + scale, opts.shadow, scale);
    if (opts.outline) {
      for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
        this._raw(ctx, s, px + dx * scale, py + dy * scale, opts.outline, scale);
      }
    }
    this._raw(ctx, s, px, py, color, scale);
  },

  _raw(ctx, s, x, y, color, scale) {
    ctx.fillStyle = color;
    for (let i = 0; i < s.length; i++) {
      const g = BITMAP_GLYPHS[s[i]];
      if (g) {
        for (let p = 0; p < 15; p++) {
          if (g[p] === '1') ctx.fillRect(x + (p % 3) * scale, y + ((p / 3) | 0) * scale, scale, scale);
        }
      }
      x += 4 * scale;
    }
  },
};

export { BitmapFont };
